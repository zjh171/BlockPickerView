//
//  main.m
//  BlockPickerViewSample
//
//  Created by zhujinhui on 15/10/4.
//  Copyright © 2015年 kyson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
